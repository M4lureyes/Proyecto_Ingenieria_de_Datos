import { Router } from "express";
import {
  crearEnsamble,
  obtenerEnsambles,
  obtenerEnsamble,
  actualizarEnsamble,
  eliminarEnsamble
} from "../controllers/ensamble.controller.js";

const router = Router();

router.post("/", crearEnsamble);
router.get("/", obtenerEnsambles);
router.get("/:id", obtenerEnsamble);
router.put("/:id", actualizarEnsamble);
router.delete("/:id", eliminarEnsamble);

export default router;
