import { Router } from "express";
import {
  crearInventario,
  obtenerInventarios,
  obtenerInventario,
  actualizarInventario,
  eliminarInventario
} from "../controllers/inventario.controller.js";

const router = Router();

router.post("/", crearInventario);
router.get("/", obtenerInventarios);
router.get("/:id", obtenerInventario);
router.put("/:id", actualizarInventario);
router.delete("/:id", eliminarInventario);

export default router;
