import { Router } from "express";
import {
  crearMovimiento,
  obtenerMovimientos,
  obtenerMovimiento,
  actualizarMovimiento,
  eliminarMovimiento
} from "../controllers/movimiento.controller.js";

const router = Router();

router.post("/", crearMovimiento);
router.get("/", obtenerMovimientos);
router.get("/:id", obtenerMovimiento);
router.put("/:id", actualizarMovimiento);
router.delete("/:id", eliminarMovimiento);

export default router;
