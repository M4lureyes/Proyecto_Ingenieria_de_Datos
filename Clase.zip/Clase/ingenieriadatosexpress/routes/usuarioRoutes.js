import { Ensamble } from "../models/ensamble.model.js";

export const crearEnsamble = async (req, res) => {
  try {
    const nuevo = await Ensamble.create(req.body);
    res.json({ mensaje: "Ensamble creado", data: nuevo });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};

export const obtenerEnsambles = async (req, res) => {
  try {
    const ensambles = await Ensamble.find();
    res.json(ensambles);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};

export const obtenerEnsamble = async (req, res) => {
  try {
    const ensamble = await Ensamble.findOne({ idEnsamble: req.params.id });
    res.json(ensamble);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};

export const actualizarEnsamble = async (req, res) => {
  try {
    const actual = await Ensamble.findOneAndUpdate(
      { idEnsamble: req.params.id },
      req.body,
      { new: true }
    );
    res.json({ mensaje: "Ensamble actualizado", data: actual });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};

export const eliminarEnsamble = async (req, res) => {
  try {
    await Ensamble.deleteOne({ idEnsamble: req.params.id });
    res.json({ mensaje: "Ensamble eliminado" });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};