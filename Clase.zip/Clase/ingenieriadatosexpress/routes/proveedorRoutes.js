import { Router } from "express";
import {
  crearProveedor,
  obtenerProveedores,
  obtenerProveedor,
  actualizarProveedor,
  eliminarProveedor
} from "../controllers/proveedor.controller.js";

const router = Router();

router.post("/", crearProveedor);
router.get("/", obtenerProveedores);
router.get("/:id", obtenerProveedor);
router.put("/:id", actualizarProveedor);
router.delete("/:id", eliminarProveedor);

export default router;
