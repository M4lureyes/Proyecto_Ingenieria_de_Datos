import { Router } from "express";
import {
  crearCompra,
  obtenerCompras,
  obtenerCompra,
  actualizarCompra,
  eliminarCompra
} from "../controllers/compra.controller.js";

const router = Router();

router.post("/", crearCompra);
router.get("/", obtenerCompras);
router.get("/:id", obtenerCompra);
router.put("/:id", actualizarCompra);
router.delete("/:id", eliminarCompra);

export default router;
