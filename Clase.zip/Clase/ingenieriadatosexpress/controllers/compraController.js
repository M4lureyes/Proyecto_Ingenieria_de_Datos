import { Compra } from "../models/compra.model.js";

export const crearCompra = async (req, res) => {
  try {
    const nueva = await Compra.create(req.body);
    res.json({ mensaje: "Compra registrada", data: nueva });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};

export const obtenerCompras = async (req, res) => {
  try {
    const compras = await Compra.find();
    res.json(compras);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};

export const obtenerCompra = async (req, res) => {
  try {
    const compra = await Compra.findOne({ idMovimientoFK: req.params.id });
    res.json(compra);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};

export const actualizarCompra = async (req, res) => {
  try {
    const actual = await Compra.findOneAndUpdate(
      { idMovimientoFK: req.params.id },
      req.body,
      { new: true }
    );
    res.json({ mensaje: "Compra actualizada", data: actual });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};

export const eliminarCompra = async (req, res) => {
  try {
    await Compra.deleteOne({ idMovimientoFK: req.params.id });
    res.json({ mensaje: "Compra eliminada" });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};
