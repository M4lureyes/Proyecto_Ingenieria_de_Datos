import { Movimiento } from "../models/movimiento.model.js";

export const crearMovimiento = async (req, res) => {
  try {
    const nuevo = await Movimiento.create(req.body);
    res.json({ mensaje: "Movimiento creado", data: nuevo });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};

export const obtenerMovimientos = async (req, res) => {
  try {
    const movimientos = await Movimiento.find();
    res.json(movimientos);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};

export const obtenerMovimiento = async (req, res) => {
  try {
    const mov = await Movimiento.findOne({ idMovimiento: req.params.id });
    res.json(mov);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};

export const actualizarMovimiento = async (req, res) => {
  try {
    const actual = await Movimiento.findOneAndUpdate(
      { idMovimiento: req.params.id },
      req.body,
      { new: true }
    );
    res.json({ mensaje: "Movimiento actualizado", data: actual });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};

export const eliminarMovimiento = async (req, res) => {
  try {
    await Movimiento.deleteOne({ idMovimiento: req.params.id });
    res.json({ mensaje: "Movimiento eliminado" });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};