import { Venta } from "../models/venta.model.js";

export const crearVenta = async (req, res) => {
  try {
    const nueva = await Venta.create(req.body);
    res.json({ mensaje: "Venta registrada", data: nueva });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};

export const obtenerVentas = async (req, res) => {
  try {
    const ventas = await Venta.find();
    res.json(ventas);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};

export const obtenerVenta = async (req, res) => {
  try {
    const venta = await Venta.findOne({ idMovimientoFK: req.params.id });
    res.json(venta);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};

export const actualizarVenta = async (req, res) => {
  try {
    const actual = await Venta.findOneAndUpdate(
      { idMovimientoFK: req.params.id },
      req.body,
      { new: true }
    );
    res.json({ mensaje: "Venta actualizada", data: actual });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};

export const eliminarVenta = async (req, res) => {
  try {
    await Venta.deleteOne({ idMovimientoFK: req.params.id });
    res.json({ mensaje: "Venta eliminada" });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};
