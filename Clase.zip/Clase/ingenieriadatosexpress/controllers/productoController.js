import { Producto } from "../models/producto.model.js";

export const crearProducto = async (req, res) => {
  try {
    const nuevo = await Producto.create(req.body);
    res.json({ mensaje: "Producto creado", data: nuevo });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};

export const obtenerProductos = async (req, res) => {
  try {
    const productos = await Producto.find();
    res.json(productos);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};

export const obtenerProducto = async (req, res) => {
  try {
    const producto = await Producto.findOne({ idProducto: req.params.id });
    res.json(producto);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};

export const actualizarProducto = async (req, res) => {
  try {
    const actual = await Producto.findOneAndUpdate(
      { idProducto: req.params.id },
      req.body,
      { new: true }
    );
    res.json({ mensaje: "Producto actualizado", data: actual });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};

export const eliminarProducto = async (req, res) => {
  try {
    await Producto.deleteOne({ idProducto: req.params.id });
    res.json({ mensaje: "Producto eliminado" });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};