import { Proveedor } from "../models/proveedor.model.js";

export const crearProveedor = async (req, res) => {
  try {
    const nuevo = await Proveedor.create(req.body);
    res.json({ mensaje: "Proveedor creado", data: nuevo });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};

export const obtenerProveedores = async (req, res) => {
  try {
    const proveedores = await Proveedor.find();
    res.json(proveedores);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};

export const obtenerProveedor = async (req, res) => {
  try {
    const prov = await Proveedor.findOne({ nitProveedor: req.params.id });
    res.json(prov);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};

export const actualizarProveedor = async (req, res) => {
  try {
    const actual = await Proveedor.findOneAndUpdate(
      { nitProveedor: req.params.id },
      req.body,
      { new: true }
    );
    res.json({ mensaje: "Proveedor actualizado", data: actual });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};

export const eliminarProveedor = async (req, res) => {
  try {
    await Proveedor.deleteOne({ nitProveedor: req.params.id });
    res.json({ mensaje: "Proveedor eliminado" });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};