import { Usuario } from "../models/usuario.model.js";

export const crearUsuario = async (req, res) => {
  try {
    const nuevo = await Usuario.create(req.body);
    res.json({ mensaje: "Usuario creado", data: nuevo });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};

export const obtenerUsuarios = async (req, res) => {
  try {
    const usuarios = await Usuario.find();
    res.json(usuarios);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};

export const obtenerUsuario = async (req, res) => {
  try {
    const usuario = await Usuario.findOne({ idUsuario: req.params.id });
    res.json(usuario);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};

export const actualizarUsuario = async (req, res) => {
  try {
    const actual = await Usuario.findOneAndUpdate(
      { idUsuario: req.params.id },
      req.body,
      { new: true }
    );
    res.json({ mensaje: "Usuario actualizado", data: actual });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};

export const eliminarUsuario = async (req, res) => {
  try {
    await Usuario.deleteOne({ idUsuario: req.params.id });
    res.json({ mensaje: "Usuario eliminado" });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};