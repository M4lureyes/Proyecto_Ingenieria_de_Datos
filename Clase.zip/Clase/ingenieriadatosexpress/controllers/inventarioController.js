import { Inventario } from "../models/inventario.model.js";

export const crearInventario = async (req, res) => {
  try {
    const nuevo = await Inventario.create(req.body);
    res.json({ mensaje: "Inventario creado", data: nuevo });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};

export const obtenerInventarios = async (req, res) => {
  try {
    const inventarios = await Inventario.find();
    res.json(inventarios);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};

export const obtenerInventario = async (req, res) => {
  try {
    const inv = await Inventario.findOne({ idInventario: req.params.id });
    res.json(inv);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};

export const actualizarInventario = async (req, res) => {
  try {
    const actual = await Inventario.findOneAndUpdate(
      { idInventario: req.params.id },
      req.body,
      { new: true }
    );
    res.json({ mensaje: "Inventario actualizado", data: actual });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};

export const eliminarInventario = async (req, res) => {
  try {
    await Inventario.deleteOne({ idInventario: req.params.id });
    res.json({ mensaje: "Inventario eliminado" });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};