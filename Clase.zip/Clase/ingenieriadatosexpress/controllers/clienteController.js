import { Cliente } from "../models/cliente.model.js";

export const crearCliente = async (req, res) => {
  try {
    const nuevo = await Cliente.create(req.body);
    res.json({ mensaje: "Cliente creado", data: nuevo });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};

export const obtenerClientes = async (req, res) => {
  try {
    const clientes = await Cliente.find();
    res.json(clientes);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};

export const obtenerCliente = async (req, res) => {
  try {
    const cli = await Cliente.findOne({ nitCliente: req.params.id });
    res.json(cli);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};

export const actualizarCliente = async (req, res) => {
  try {
    const actual = await Cliente.findOneAndUpdate(
      { nitCliente: req.params.id },
      req.body,
      { new: true }
    );
    res.json({ mensaje: "Cliente actualizado", data: actual });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};

export const eliminarCliente = async (req, res) => {
  try {
    await Cliente.deleteOne({ nitCliente: req.params.id });
    res.json({ mensaje: "Cliente eliminado" });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};
