import mongoose from "mongoose";

const usuarioSchema = new mongoose.Schema({
  idUsuario: Number,
  nombreUsuario: String,
  rolUsuario: String,
  nickname: String,
  claveUsuario: String,
  correoUsuario: String,
  telefono: String,
  estadoUsuario: String,
  fechaRegistroUsuario: Date
});

export const Usuario = mongoose.model("Usuario", usuarioSchema);